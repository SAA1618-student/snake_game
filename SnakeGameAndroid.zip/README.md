# Snake Game (Android, Kotlin)

A tiny Snake game you can build to APK **on GitHub** – perfect if you only have an Android phone.

## How to use (no PC needed)
1. Create a new **public or private** repository on GitHub (name it anything).
2. Upload the files in this folder to your repository (you can use the GitHub mobile app or website). Keep the same folder structure.
3. Go to the **Actions** tab in your repo. GitHub will ask to enable workflows — click **Enable**.
4. The workflow will build your app automatically on each push. When it finishes, open the latest workflow run and download the artifact:
   **`app-debug.apk`**.
5. Install the APK on your Android phone (you may need to allow installs from unknown sources).

## Local run (optional)
If you ever use a computer with Android Studio: open the project and run it on an emulator or device.

## Controls
- **Swipe** to change direction.
- Eat food to grow. Avoid walls and yourself.
- Tap after game over to restart.

## Tech
- Kotlin + Android View
- Min SDK 24, Target 34
- GitHub Actions compiles the APK using JDK 17 + Android SDK